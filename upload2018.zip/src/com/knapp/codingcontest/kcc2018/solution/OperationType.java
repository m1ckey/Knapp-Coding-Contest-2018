package com.knapp.codingcontest.kcc2018.solution;

// KCC2018-java
// Created by Michael Krickl in 2018


public enum OperationType
{
  STORE,
  LOAD,
  MOVE,
  PICK
}
